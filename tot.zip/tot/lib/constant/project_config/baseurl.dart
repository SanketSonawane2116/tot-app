class ProjectConfig
{
  static const MainUrl = "https://dog.ceo/api/";
}