import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryColor = Color(0xFF0074BB);

}