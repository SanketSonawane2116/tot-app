import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../constant/color_string/color_string_constant.dart';
import '../../database/dog_databse.dart';
import '../dog_details/dog_details_screen.dart';
import '../home_screen/home_page.dart';
import 'detaailed_saved_data_screen.dart';

class SavedDogDataScreen extends StatefulWidget {
  const SavedDogDataScreen({super.key});

  @override
  State<SavedDogDataScreen> createState() => _SavedDogDataScreenState();
}

class _SavedDogDataScreenState extends State<SavedDogDataScreen> {
  List<Map<String, dynamic>> savedDogs = [];

  @override
  void initState() {
    super.initState();
    _loadSavedDogs();
  }

  Future<void> _loadSavedDogs() async {
    final data = await DatabaseHelper.instance.getAllBreeds();
    setState(() {
      savedDogs = data;
    });
  }

  Future<void> _deleteDog(String breedName) async {
    await DatabaseHelper.instance.deleteDogRecord(breedName);
    _loadSavedDogs();
  }

  void _showDeleteConfirmDialog(String breedName) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Confirmation'),
        content: const Text('Are you sure you want to delete this dog breed?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await _deleteDog(breedName);
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Get.offAll(() => HomeScreen());
        return false; // prevent default back action
      },
      child: MediaQuery(
        data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
        child: Scaffold(
            appBar: AppBar(
              title: const Text(
                "Saved Dog's Data",
                style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
              ),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () {
                  Get.offAll(() => HomeScreen());
                },
              ),
              backgroundColor: AppColors.primaryColor,
              centerTitle: true,
              elevation: 4,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.vertical(bottom: Radius.circular(25)),
              ),
              flexibleSpace: Container(
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(bottom: Radius.circular(25)),
                  gradient: LinearGradient(
                    colors: [AppColors.primaryColor, Colors.teal.shade700],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
            ),
            backgroundColor: const Color(0xFFF6F6F6),
          body: savedDogs.isEmpty
              ? const Center(child: Text("No saved dog data found."))
              : ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: savedDogs.length,
            itemBuilder: (context, index) {
              final dog = savedDogs[index];
              return GestureDetector(

                child: Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: ListTile(
                    title: Row(
                      children: [
                        Expanded(
                          flex: 1,
                          child: Text("${index + 1}", style: const TextStyle(fontWeight: FontWeight.bold)),
                        ),
                        Expanded(
                          flex: 3,
                          child: Text(dog['breed_name'] ?? 'Unknown'),
                        ),
                        Expanded(
                          flex: 2,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit, color: Colors.blue),
                                onPressed: () {
                                  final breed = dog['breed_name'] ?? '';
                                  final imageUrl = dog['breed_image'] ?? '';
                                  final subBreedsString = dog['sub_breeds'] ?? '';
                                  final subBreeds = subBreedsString.isNotEmpty
                                      ? subBreedsString.split(',') // assuming sub-breeds are stored as comma-separated string
                                      : <String>[];

                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => SavedDogDetailScreen(
                                        breed: breed,
                                        subBreeds: subBreeds,
                                        imageUrl: imageUrl,
                                      ),
                                    ),
                                  );
                                },

                              ),
                              IconButton(
                                icon: const Icon(Icons.delete, color: Colors.red),
                                onPressed: () => _showDeleteConfirmDialog(dog['breed_name']),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),// your body here
        ),
      ),
    );
  }

}
