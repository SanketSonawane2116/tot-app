import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:tot/view/dog_details/dog_details_screen.dart';

import '../../constant/color_string/color_string_constant.dart';
import '../../constant/image_string/image_string.dart';
import '../../controller/dog_breeds/dog_breed_list_controller.dart';
import '../../controller/network_controller.dart';
import '../../database/dog_databse.dart';
import '../journey/journey_history_screen.dart';
import '../journey/journey_tracking_screen.dart';
import '../offline_saved_dog_data/offline_saved_dog_data_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  var size, height, width;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final NetworkController networkController = Get.put(NetworkController());
  final DogNameController dogNameController = Get.put(DogNameController());
  int recordCount = 0;

  Future<void> showInternetPopup() async {
    final connectivityResult = await Connectivity().checkConnectivity();
    if (connectivityResult.contains(ConnectivityResult.mobile)) {
    } else if (connectivityResult.contains(ConnectivityResult.wifi)) {
    } else if (connectivityResult.contains(ConnectivityResult.none)) {
      Get.defaultDialog(
        title: '',
        content: Container(
          width: double.infinity,
          child: Column(
            children: [
              Text(
                'Please Check Your Internet Please try again later..!',
                style: TextStyle(fontSize: 18),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text('OK', style: TextStyle(color: Colors.teal)),
                  ),
                ],
              ),
            ],
          ),
        ),
        barrierDismissible: false,
        radius: 0,
      );
      return;
    }
  }

  @override
  void initState() {
    super.initState();
    showInternetPopup();
    fetchRecordCount();
    dogNameController.fetchDogList();
  }
  Future<void> fetchRecordCount() async {
    final db = await DatabaseHelper().database;
    final List<Map<String, dynamic>> result = await db.query(DatabaseHelper.tbl_dog_data);
    setState(() {
      recordCount = result.length;
    });
  }
  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    height = size.height;
    width = size.width;

    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
      child: Scaffold(
        backgroundColor: Colors.white,
        key: _scaffoldKey,
        appBar: AppBar(
          title: const Text(
            'TOT APP',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          centerTitle: true,
          elevation: 0,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(25)),
          ),
          iconTheme: const IconThemeData(color: Colors.white),

          // 👇 Location icon on the left
          leading: IconButton(
            icon: const Icon(Icons.location_on, color: Colors.white, size: 28),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => JourneyHistoryScreen()),
              );
            },
          ),

          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 16, top: 10),
              child: Stack(
                alignment: Alignment.topRight,
                children: [
                  IconButton(
                    icon: const Icon(Icons.notifications, color: Colors.white, size: 28),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SavedDogDataScreen()),
                      );
                    },
                  ),
                  if (recordCount > 0) // conditionally show badge
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: const BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                      constraints: const BoxConstraints(minWidth: 20, minHeight: 20),
                      child: Center(
                        child: Text(
                          '$recordCount',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
          flexibleSpace: Container(
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(25)),
              gradient: LinearGradient(
                colors: [AppColors.primaryColor, Colors.teal.shade700],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
        ),



        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8),
              child: Material(
                elevation: 4,
                borderRadius: BorderRadius.circular(30),
                shadowColor: Colors.teal.withOpacity(0.3),
                child: Obx(() {
                  return TextField(
                    controller: TextEditingController(text: dogNameController.searchQuery.value)
                      ..selection = TextSelection.fromPosition(
                        TextPosition(offset: dogNameController.searchQuery.value.length),
                      ),
                    onChanged: (value) => dogNameController.searchQuery.value = value,
                    decoration: InputDecoration(
                      hintText: "Search ...",
                      prefixIcon: const Icon(Icons.search, color: Colors.teal),
                      suffixIcon: dogNameController.searchQuery.value.isNotEmpty
                          ? IconButton(
                        icon: const Icon(Icons.close, color: Colors.grey),
                        onPressed: () => dogNameController.searchQuery.value = '',
                      )
                          : null,
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    style: const TextStyle(fontSize: 16),
                  );
                }),
              ),
            ),


            Expanded(
              child: RefreshIndicator(
                onRefresh: () async {
                  await dogNameController.fetchDogList();
                },
                child: Obx(() {
                  if (dogNameController.isLoading.value) {
                    return const Center(child: CircularProgressIndicator());
                  } else if (dogNameController.errorMessage.isNotEmpty) {
                    return Center(child: Text(dogNameController.errorMessage.value));
                  } else {
                    final filteredKeys = dogNameController.filteredBreedKeys;

                    return GridView.builder(
                      padding: const EdgeInsets.all(12),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: 0.85,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                      ),
                      itemCount: filteredKeys.length,
                      itemBuilder: (context, index) {
                        final breed = filteredKeys[index];
                        final subBreeds = dogNameController.dogBreedMap[breed]!;

                        return FutureBuilder<String>(
                          future: dogNameController.fetchDogImage(breed),
                          builder: (context, snapshot) {
                            final imageUrl = snapshot.data ?? '';

                            final List<Color> pastelColors = [
                              const Color(0xFFEBDFFF),
                              const Color(0xFFFFE6E6),
                              const Color(0xFFE2FFE8),
                              const Color(0xFFD8E7FF),
                              const Color(0xFFFFF3DB),
                              const Color(0xFFDFF6FF),
                            ];
                            final bgColor = pastelColors[index % pastelColors.length];

                            return InkWell(
                              onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => DogDetailScreen(
                                    breed: breed,
                                    subBreeds: subBreeds,
                                    imageUrl: imageUrl,
                                  ),
                                ),
                              ),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: bgColor,
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                padding: const EdgeInsets.all(12),
                                child: Column(
                                  children: [
                                    const SizedBox(height: 8),
                                    Expanded(
                                      child: imageUrl.isNotEmpty
                                          ? Image.network(
                                        imageUrl,
                                        fit: BoxFit.contain,
                                        errorBuilder: (_, __, ___) =>
                                        const Icon(Icons.image, size: 60),
                                      )
                                          : const Icon(Icons.image, size: 60),
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      breed.capitalizeFirst ?? breed,
                                      style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Tooltip(
                                      message: subBreeds.join(', '),
                                      child: Text(
                                        subBreeds.isNotEmpty
                                            ? subBreeds.join(', ')
                                            : "No sub-breeds",
                                        style: const TextStyle(
                                          fontSize: 13,
                                          color: Colors.black54,
                                        ),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.center,
                                      ),
                                    ),

                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      },
                    );
                  }
                }),
              ),
            ),

          ],
        ),

        floatingActionButton: FloatingActionButton.extended(
          onPressed: () async {
            bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
            LocationPermission permission;

            // Step 1: If GPS is not enabled, open settings
            if (!serviceEnabled) {
              await Geolocator.openLocationSettings();
              return; // Exit here; user will come back after enabling GPS
            }

            // Step 2: Check permission
            permission = await Geolocator.checkPermission();

            if (permission == LocationPermission.denied) {
              permission = await Geolocator.requestPermission();
            }

            if (permission == LocationPermission.deniedForever) {

              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Location permission permanently denied. Please enable it in app settings.')),
              );
              return;
            }

            // Step 3: If granted, navigate to tracking screen
            if (permission == LocationPermission.always || permission == LocationPermission.whileInUse) {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const JourneyTrackingScreen()),
              );
            }
          },
          label: const Text("Track Journey"),
          icon: const Icon(Icons.directions_walk),
          backgroundColor: Colors.teal,
        ),



        bottomNavigationBar: Container(
          height: 40,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [AppColors.primaryColor, Colors.teal.shade700],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: BottomAppBar(
            color: Colors.transparent, // Make it transparent to show gradient
            elevation: 0,
            padding: const EdgeInsets.symmetric(vertical: 1),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: const [
                  SizedBox(width: 20),
                  // Add any icon/text here
                ],
              ),
            ),
          ),
        ),

      ),
    );
  }
}
