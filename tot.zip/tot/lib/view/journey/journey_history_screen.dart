import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../../constant/color_string/color_string_constant.dart';
import '../../database/dog_databse.dart';
import '../home_screen/home_page.dart';
import 'journey_map_screen.dart';

class JourneyHistoryScreen extends StatelessWidget {
  const JourneyHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Journey History",
          style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Get.offAll(() => HomeScreen());
          },
        ),
        backgroundColor: AppColors.primaryColor,
        centerTitle: true,
        elevation: 4,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(25)),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: const BorderRadius.vertical(bottom: Radius.circular(25)),
            gradient: LinearGradient(
              colors: [AppColors.primaryColor, Colors.teal.shade700],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: DatabaseHelper().getJourneyHistory(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());

          final journeys = snapshot.data!;
          if (journeys.isEmpty) return const Center(child: Text('No journey data found.'));

          return ListView.builder(
            itemCount: journeys.length,
            itemBuilder: (context, index) {
              final item = journeys[index];

              String? formatDateTime(String? rawDate) {
                try {
                  if (rawDate == null || rawDate.isEmpty) return '-';
                  final date = DateFormat('yyyy-MM-dd HH:mm:ss').parse(rawDate);
                  return DateFormat.yMMMd().add_jm().format(date);
                } catch (e) {
                  return rawDate; // fallback
                }
              }

              final start = formatDateTime(item['startTime']);
              final end = formatDateTime(item['endTime']);

              final distance = item['distance'] != null
                  ? '${(item['distance'] as num).toStringAsFixed(2)} km'
                  : '--';
              final duration = item['duration'] ?? '--';

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                elevation: 2,
                child: ListTile(
                  leading: const Icon(Icons.location_on, color: Colors.teal),
                  title: Text('Start: $start\nEnd: $end'),
                  subtitle: Text('Distance: $distance\nDuration: $duration'),
                  onTap: () {
                    final startLat = double.tryParse(item['startLat'].toString()) ?? 0.0;
                    final startLng = double.tryParse(item['startLng'].toString()) ?? 0.0;
                    final endLat = double.tryParse(item['endLat'].toString()) ?? 0.0;
                    final endLng = double.tryParse(item['endLng'].toString()) ?? 0.0;

                    if (startLat != 0.0 && startLng != 0.0 && endLat != 0.0 && endLng != 0.0) {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => JourneyMapScreen(
                            startLat: startLat,
                            startLng: startLng,
                            endLat: endLat,
                            endLng: endLng,
                          ),
                        ),
                      );
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Location data missing")),
                      );
                    }
                  },
                ),
              );

            },
          );
        },
      ),
    );
  }
}

