import 'dart:io';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static Database? _database;
  static const String dbName = 'dog_details.db';
  static const String tbl_dog_data = 'tbl_dog_data';
  static const String tbl_journey = 'tbl_journey';

  static final DatabaseHelper instance = DatabaseHelper._internal();
  DatabaseHelper._internal();

  factory DatabaseHelper() => instance;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await initDatabase();
    return _database!;
  }

  Future<Database> initDatabase() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, dbName);
    return await openDatabase(path, version: 1, onCreate: _createTable);
  }

  void _createTable(Database db, int version) async {

    await db.execute('''
    CREATE TABLE $tbl_dog_data (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      breed_name TEXT UNIQUE,
      breed_image TEXT,
      sub_breeds TEXT
    )
  ''');

    await db.execute('''
    CREATE TABLE $tbl_journey (
       id INTEGER PRIMARY KEY AUTOINCREMENT,
          startLat REAL,
          startLng REAL,
          endLat REAL,
          endLng REAL,
          startTime TEXT,
          endTime TEXT,
          distance REAL,
          duration TEXT
    )
  ''');
  }

  Future<int> insertDogData(Map<String, dynamic> data) async {
    try {
      final db = await database;
      return await db.insert(tbl_dog_data, data);
    } catch (e) {
      print('Error inserting data: $e');
      return 0;
    }
  }

  Future<int> insertJourneyStart({
    required double startLat,
    required double startLng,
    required String startTime,
  }) async {
    final db = await database;
    return await db.insert(tbl_journey, {
      'startLat': startLat,
      'startLng': startLng,
      'startTime': startTime,
    });
  }

  Future<int> updateJourneyEnd({
    required int id,
    required double endLat,
    required double endLng,
    required String endTime,
    required double distance,
    required String duration,
  }) async {
    final db = await database;
    return await db.update(
      tbl_journey,
      {
        'endLat': endLat,
        'endLng': endLng,
        'endTime': endTime,
        'distance': distance,
        'duration': duration,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<List<Map<String, dynamic>>> getJourneyHistory() async {
    final db = await database;
    return await db.query(tbl_journey, orderBy: 'id DESC');
  }

  Future<int> updateBreedData(Map<String, dynamic> data, String breedName) async {
    final db = await database;
    return await db.update(
      tbl_dog_data,
      data,
      where: 'breed_name = ?',
      whereArgs: [breedName],
    );
  }

  Future<int> deleteDogRecord(String breedName) async {
    final db = await database;
    return await db.delete(
      tbl_dog_data,
      where: 'breed_name = ?',
      whereArgs: [breedName],
    );
  }

  Future<int> deleteAllDogRecords() async {
    final db = await database;
    return await db.delete(tbl_dog_data);
  }

  Future<bool> dogDataExists(String breedName) async {
    final db = await database;
    final result = await db.query(
      tbl_dog_data,
      where: 'breed_name = ?',
      whereArgs: [breedName],
    );
    return result.isNotEmpty;
  }


  Future<List<Map<String, dynamic>>> getAllBreeds() async {
    final db = await database;
    return await db.query(tbl_dog_data);
  }

}
