class SavedDog {
  final String breed;
  final String subBreed;
  final String imageUrl;

  SavedDog({
    required this.breed,
    required this.subBreed,
    required this.imageUrl,
  });

  Map<String, dynamic> toMap() => {
    'breed': breed,
    'subBreed': subBreed,
    'imageUrl': imageUrl,
  };

  factory SavedDog.fromMap(Map<String, dynamic> map) => SavedDog(
    breed: map['breed'],
    subBreed: map['subBreed'],
    imageUrl: map['imageUrl'],
  );
}
