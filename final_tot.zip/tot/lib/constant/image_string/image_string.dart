const String app_logo = "assets/images/tot_app.png";
const String side_menu = "assets/images/sidemenu.png";
const String dog_placeholder = "assets/images/dog_placeholder.png";
const String splash_img = "assets/images/splash_img.png";