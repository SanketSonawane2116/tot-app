import 'package:get/get.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

class NetworkController extends GetxController {
  var isConnected = true.obs;

  @override
  void onInit() {
    super.onInit();
    _checkInitialConnection();
    Connectivity().onConnectivityChanged.listen(_updateConnectionStatus);
  }

  void _updateConnectionStatus(List<ConnectivityResult> results) {
    bool connectionNow = results.any((result) =>
    result == ConnectivityResult.mobile ||
        result == ConnectivityResult.wifi);
    if (!isConnected.value && connectionNow) {
      /* try {
        Get.find<AttendanceController>().fetchAttendanceStatus();
      } catch (e) {
        print('AttendanceController not found: $e');
      }*/
    }

    isConnected.value = connectionNow;
  }

  void _checkInitialConnection() async {
    final result = await Connectivity().checkConnectivity();
    isConnected.value = result == ConnectivityResult.mobile ||
        result == ConnectivityResult.wifi;
  }
}