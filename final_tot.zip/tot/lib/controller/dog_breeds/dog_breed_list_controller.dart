// lib/controllers/dog_name_controller.dart

import 'package:get/get.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

import '../../constant/project_config/baseurl.dart';
import '../../model/dog_details/dog_details.dart';


class DogNameController extends GetxController {
  var dogBreedMap = <String, List<String>>{}.obs;
  var isLoading = true.obs;
  var errorMessage = ''.obs;
  var searchQuery = ''.obs;

  @override
  void onInit() {
    super.onInit();
    fetchDogList();
  }

  Future<void> fetchDogList() async {
    isLoading(true);
    try {
      final response = await http.get(
        Uri.parse('${ProjectConfig.MainUrl}breeds/list/all'),
      );

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final dogModel = DogBreedModel.fromJson(jsonData);
        dogBreedMap.value = dogModel.message;
      } else {
        errorMessage.value = 'Failed to load dog breeds.';
      }
    } catch (e) {
      errorMessage.value = 'An error occurred: $e';
    } finally {
      isLoading(false);
    }
  }
  Future<String> fetchDogImage(String breed) async {
    try {
      final response = await http.get(
        Uri.parse("${ProjectConfig.MainUrl}breed/${breed.toLowerCase()}/images/random"),
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['message']; // Image URL
      } else {
        throw Exception('Failed to load image');
      }
    } catch (e) {
      return ''; // fallback or default image URL
    }
  }
  List<String> get filteredBreedKeys {
    if (searchQuery.value.isEmpty) return dogBreedMap.keys.toList();
    return dogBreedMap.keys
        .where((breed) => breed.toLowerCase().contains(searchQuery.value.toLowerCase()))
        .toList();
  }

}
