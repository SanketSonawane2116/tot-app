class DogBreedData {
  final String breedName;
  final String breedImage;
  final List<String> subBreeds;

  DogBreedData({
    required this.breedName,
    required this.breedImage,
    required this.subBreeds,
  });

  Map<String, dynamic> toMap() {
    return {
      'breed_name': breedName,
      'breed_image': breedImage,
      'sub_breeds': subBreeds.join(','),
    };
  }

  factory DogBreedData.fromMap(Map<String, dynamic> map) {
    return DogBreedData(
      breedName: map['breed_name'],
      breedImage: map['breed_image'],
      subBreeds: map['sub_breeds'] != null && map['sub_breeds'].toString().isNotEmpty
          ? map['sub_breeds'].toString().split(',').map((e) => e.trim()).toList()
          : [],
    );
  }
}
