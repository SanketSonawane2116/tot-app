import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../constant/color_string/color_string_constant.dart';
import '../../database/dog_databse.dart';
import '../dog_details/dog_details_screen.dart';
import '../home_screen/home_page.dart';
import 'detaailed_saved_data_screen.dart';

class SavedDogDataScreen extends StatefulWidget {
  const SavedDogDataScreen({super.key});

  @override
  State<SavedDogDataScreen> createState() => _SavedDogDataScreenState();
}

class _SavedDogDataScreenState extends State<SavedDogDataScreen> {
  List<Map<String, dynamic>> savedDogs = [];

  @override
  void initState() {
    super.initState();
    _loadSavedDogs();
  }

  Future<void> _loadSavedDogs() async {
    final data = await DatabaseHelper.instance.getAllBreeds();
    setState(() {
      savedDogs = data;
    });
  }

  Future<void> _deleteDog(String breedName) async {
    await DatabaseHelper.instance.deleteDogRecord(breedName);
    _loadSavedDogs();
  }

  void _showDeleteConfirmDialog(String breedName) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Confirmation'),
        content: const Text('Are you sure you want to delete this dog breed?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await _deleteDog(breedName);
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Get.offAll(() => HomeScreen());
        return false; // prevent default back action
      },
      child: MediaQuery(
        data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
        child: Scaffold(
            appBar: AppBar(
              title: const Text(
                "Saved Dog's Data",
                style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
              ),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () {
                  Get.offAll(() => HomeScreen());
                },
              ),
              backgroundColor: AppColors.primaryColor,
              centerTitle: true,
              elevation: 4,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.vertical(bottom: Radius.circular(25)),
              ),
              flexibleSpace: Container(
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(bottom: Radius.circular(25)),
                  gradient: LinearGradient(
                    colors: [AppColors.primaryColor, Colors.teal.shade700],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
            ),
            backgroundColor: const Color(0xFFF6F6F6),
          body: savedDogs.isEmpty
              ? const Center(child: Text("No saved dog data found."))
              : ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: savedDogs.length,
            itemBuilder: (context, index) {
              final dog = savedDogs[index];
              return GestureDetector(

                child: Card(
                  elevation: 4,
                  margin: const EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // 🐶 Thumbnail Image
                        ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.network(
                            dog['breed_image'] ?? '',
                            width: 60,
                            height: 60,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) => const Icon(Icons.image_not_supported, size: 60),
                          ),
                        ),
                        const SizedBox(width: 12),

                        // 📄 Breed info
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                dog['breed_name'] ?? 'Unknown',
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              if ((dog['sub_breeds'] ?? '').isNotEmpty)
                                Text(
                                  'Sub-breeds: ${dog['sub_breeds']}',
                                  style: const TextStyle(
                                    fontSize: 13,
                                    color: Colors.grey,
                                  ),
                                ),
                            ],
                          ),
                        ),

                        // 👁️‍🗨️ Actions
                        Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.remove_red_eye, color: Colors.blueAccent),
                              onPressed: () {
                                final breed = dog['breed_name'] ?? '';
                                final imageUrl = dog['breed_image'] ?? '';
                                final subBreedsString = dog['sub_breeds'] ?? '';
                                final subBreeds = subBreedsString.isNotEmpty
                                    ? subBreedsString.split(',')
                                    : <String>[];

                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => SavedDogDetailScreen(
                                      breed: breed,
                                      subBreeds: subBreeds,
                                      imageUrl: imageUrl,
                                    ),
                                  ),
                                );
                              },
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete_forever, color: Colors.redAccent),
                              onPressed: () => _showDeleteConfirmDialog(dog['breed_name']),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),

              );
            },
          ),// your body here
        ),
      ),
    );
  }

}
