import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../constant/color_string/color_string_constant.dart';

class JourneyMapScreen extends StatelessWidget {
  final double startLat;
  final double startLng;
  final double endLat;
  final double endLng;

  const JourneyMapScreen({
    super.key,
    required this.startLat,
    required this.startLng,
    required this.endLat,
    required this.endLng,
  });

  @override
  Widget build(BuildContext context) {
    final LatLng start = LatLng(startLat, startLng);
    final LatLng end = LatLng(endLat, endLng);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Journey Map",
          style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        backgroundColor: AppColors.primaryColor,
        centerTitle: true,
        elevation: 4,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(25)),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: const BorderRadius.vertical(bottom: Radius.circular(25)),
            gradient: LinearGradient(
              colors: [AppColors.primaryColor, Colors.teal.shade700],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: start,
          zoom: 12,
        ),
        markers: {
          Marker(markerId: const MarkerId('start'), position: start, infoWindow: const InfoWindow(title: 'Start')),
          Marker(markerId: const MarkerId('end'), position: end, infoWindow: const InfoWindow(title: 'End')),
        },
        polylines: {
          Polyline(
            polylineId: const PolylineId('route'),
            points: [start, end],
            color: Colors.teal,
            width: 4,
          )
        },
      ),
    );
  }
}
