import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'dart:async';

import '../../constant/color_string/color_string_constant.dart';
import '../../database/dog_databse.dart';

class JourneyTrackingScreen extends StatefulWidget {
  const JourneyTrackingScreen({super.key});

  @override
  State<JourneyTrackingScreen> createState() => _JourneyTrackingScreenState();
}

class _JourneyTrackingScreenState extends State<JourneyTrackingScreen> {
  GoogleMapController? _mapController;
  List<LatLng> _route = [];
  Marker? _sourceMarker;
  Marker? _destinationMarker;
  bool _tracking = false;
  StreamSubscription<Position>? _positionStream;

  @override
  void initState() {
    super.initState();
    _fetchInitialLocation();
  }
  Future<void> _fetchInitialLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
      permission = await Geolocator.requestPermission();
    }

    if (serviceEnabled && permission != LocationPermission.denied && permission != LocationPermission.deniedForever) {
      Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      setState(() {
        _initialCameraPosition = CameraPosition(
          target: LatLng(position.latitude, position.longitude),
          zoom: 16,
        );
      });
    } else {
      // Default to India center
      _initialCameraPosition = const CameraPosition(
        target: LatLng(20.5937, 78.9629),
        zoom: 5,
      );
    }
  }

  @override
  void dispose() {
    _positionStream?.cancel();
    super.dispose();
  }
  int? _journeyId;
  DateTime? _startTime;
  DateTime? _endTime;

  Future<void> _startTracking() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    LocationPermission permission = await Geolocator.requestPermission();
    if (!serviceEnabled || permission == LocationPermission.deniedForever) return;

    _route.clear();

    _positionStream = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 5,
      ),
    ).listen((Position position) async {
      LatLng current = LatLng(position.latitude, position.longitude);

      setState(() {
        _route.add(current);
        if (_route.length == 1) {
          _sourceMarker = Marker(markerId: const MarkerId('source'), position: current);
        }
      });

      if (_route.length == 1) {
        _startTime = DateTime.now();
        _journeyId = await DatabaseHelper().insertJourneyStart(
          startLat: current.latitude,
          startLng: current.longitude,
          startTime: DateFormat.Hms().format(_startTime!),
        );
      }

      _mapController?.animateCamera(CameraUpdate.newLatLng(current));
    });

    setState(() => _tracking = true);
  }

  Future<void> _stopTracking() async {
    await _positionStream?.cancel();

    if (_route.isNotEmpty && _journeyId != null && _startTime != null) {
      final end = _route.last;
      final endTime = DateTime.now();
      final durationObj = endTime.difference(_startTime!);
      final duration = durationObj.toString().split('.').first;
      final distance = _calculateDistanceInKm(_route);
      _endTime = DateTime.now();

      await DatabaseHelper().updateJourneyEnd(
        id: _journeyId!,
        endLat: end.latitude,
        endLng: end.longitude,
        endTime: DateFormat.Hms().format(_endTime!),
        distance: distance,
        duration: duration,
      );

      setState(() {
        _destinationMarker = Marker(
          markerId: const MarkerId('destination'),
          position: end,
        );
      });

      // Show attractive success dialog
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Row(
            children: const [
              Icon(Icons.check_circle, color: Colors.green),
              SizedBox(width: 8),
              Text("Success"),
            ],
          ),
          content: const Text(
            "Your journey has been stored successfully!",
            style: TextStyle(fontSize: 16),
          ),
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: Colors.teal,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onPressed: () {
                Navigator.of(context).pop(); // close dialog
                Navigator.of(context).pop(); // navigate to Home
              },
              child: const Text("OK"),
            ),
          ],
        ),
      );
    }

    setState(() => _tracking = false);
  }


  CameraPosition? _initialCameraPosition;
  @override
  Widget build(BuildContext context) {
    if (_initialCameraPosition == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Live Journey Tracker",
          style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        backgroundColor: AppColors.primaryColor,
        centerTitle: true,
        elevation: 4,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(25)),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: const BorderRadius.vertical(bottom: Radius.circular(25)),
            gradient: LinearGradient(
              colors: [AppColors.primaryColor, Colors.teal.shade700],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: _initialCameraPosition!,
            myLocationEnabled: true,
            polylines: {
              if (_route.length > 1)
                Polyline(
                  polylineId: const PolylineId('route'),
                  points: _route,
                  color: Colors.blue,
                  width: 5,
                ),
            },
            markers: {
              if (_sourceMarker != null) _sourceMarker!,
              if (_destinationMarker != null) _destinationMarker!,
            },
            onMapCreated: (controller) => _mapController = controller,
          ),
          Positioned(
            bottom: 80,
            left: 20,
            right: 20,
            child: ElevatedButton.icon(
              icon: Icon(_tracking ? Icons.stop : Icons.play_arrow),
              label: Text(_tracking ? 'Stop Journey' : 'Start Journey'),
              onPressed: () => _tracking ? _stopTracking() : _startTracking(),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor: _tracking ? Colors.red : Colors.green,
              ),
            ),
          ),
        ],
      ),
    );
  }

  double _calculateDistanceInKm(List<LatLng> points) {
    double total = 0.0;
    for (int i = 0; i < points.length - 1; i++) {
      total += Geolocator.distanceBetween(
        points[i].latitude,
        points[i].longitude,
        points[i + 1].latitude,
        points[i + 1].longitude,
      );
    }
    return total / 1000; // Convert to kilometers
  }

}
