
class DogBreedModel {
  final Map<String, List<String>> message;
  final String status;

  DogBreedModel({required this.message, required this.status});

  factory DogBreedModel.fromJson(Map<String, dynamic> json) {
    return DogBreedModel(
      message: Map<String, List<String>>.from(
        json['message'].map(
              (key, value) => MapEntry(key, List<String>.from(value)),
        ),
      ),
      status: json['status'],
    );
  }
}